package com.codingdojo.DaikichiPath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DaikichiPathApplication {

	public static void main(String[] args) {
		SpringApplication.run(DaikichiPathApplication.class, args);
	}

}
